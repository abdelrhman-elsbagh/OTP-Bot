<!DOCTYPE html>
<html>
<head>
    <title>OVX</title>
</head>
<body>
<p>{{ $messageContent }}</p>
</body>
</html>
